package com.example.safetracehub.myapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import at.markushi.ui.CircleButton;

public class beersview extends AppCompatActivity {

    ArrayList<beersList> beersLists = new ArrayList<>();
    ListView beerLview;
    EditText beerSearch;
    ListViewAdapter adapter;
    AutoCompleteTextView searchBc;
    DatabaseHelper databaseHelper;
    ArrayList<String> searchBcLIst = new ArrayList<>();
    Button cart, order, asc, desc;
    ArrayList<String> drop = new ArrayList<>();
    String ID;
    TextView set;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beersview);
        beerLview = (ListView) findViewById(R.id.beerListview);
        cart = (Button) findViewById(R.id.cart);
        order = (Button) findViewById(R.id.order);
        asc = (Button) findViewById(R.id.asc);
        desc = (Button) findViewById(R.id.desc);
        searchBc = (AutoCompleteTextView) findViewById(R.id.searchBc);
        set = (TextView) findViewById(R.id.set);
        ID = getIntent().getStringExtra("ID");
        databaseHelper = new DatabaseHelper(this);
        beerLview.setVisibility(View.VISIBLE);
        final CircleButton beer = (CircleButton) findViewById(R.id.beer);
        /*
        * for beer icon click to view All crafted beer details.
        * */
        beer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                asc.setBackgroundColor(Color.parseColor("#1E8449"));
                order.setBackgroundColor(Color.parseColor("#1E8449"));
                cart.setBackgroundColor(Color.parseColor("#1E8449"));
                desc.setBackgroundColor(Color.parseColor("#1E8449"));
                beersLists = new ArrayList<>();
                set.setText("Crafted Beers");
                Cursor data = databaseHelper.getListContents();

                if (data.getCount() == 0) {
                    Toast.makeText(beersview.this, "No Beers here", Toast.LENGTH_LONG).show();
                    beerLview.setVisibility(View.INVISIBLE);
                } else {
                    beerLview.setVisibility(View.VISIBLE);
                    while (data.moveToNext()) {
                        drop.add(data.getString(1));
                        final beersList storyList = new beersList(data.getString(1), data.getString(2), data.getString(3));
                        beersLists.add(storyList);
                    }
                    adapter = new ListViewAdapter(beersview.this, beersLists);
                    beerLview.setAdapter(adapter);
                    beerLview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            long viewId = view.getId();
                            try {

                                if (viewId == R.id.Alcohol) {
                                    databaseHelper.Cart(ID, beersLists.get(position).getName(), beersLists.get(position).getStyle(), beersLists.get(position).getOunces());
                                    Toast.makeText(beersview.this, "Carted", Toast.LENGTH_SHORT).show();
                                }
                                if (viewId == R.id.Style) {
                                    databaseHelper.Order(ID, beersLists.get(position).getName(), beersLists.get(position).getStyle(), beersLists.get(position).getOunces());
                                    Toast.makeText(beersview.this, "Ordered", Toast.LENGTH_SHORT).show();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }
            }
        });
        /*
        * View All crafted Beer details.
        * */
        set.setText("Crafted Beers");
        Cursor data = databaseHelper.getListContents();

        if (data.getCount() == 0) {
            Toast.makeText(beersview.this, "No Beers here", Toast.LENGTH_LONG).show();
        } else {
            while (data.moveToNext()) {
                drop.add(data.getString(1));
                final beersList storyList = new beersList(data.getString(1), data.getString(2), data.getString(3));
                beersLists.add(storyList);
            }
            adapter = new ListViewAdapter(beersview.this, beersLists);
            beerLview.setAdapter(adapter);
            beerLview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    long viewId = view.getId();
                    try {

                        if (viewId == R.id.Alcohol) {
                            /*
                             * carting functionality(inserting userid and selected beer details).
                             * */
                            databaseHelper.Cart(ID, beersLists.get(position).getName(), beersLists.get(position).getStyle(), beersLists.get(position).getOunces());
                            Toast.makeText(beersview.this, "Carted", Toast.LENGTH_SHORT).show();
                        }
                        if (viewId == R.id.Style) {
                            /*
                             * order functionality(inserting userid and selected beer details).
                             * */
                            databaseHelper.Order(ID, beersLists.get(position).getName(), beersLists.get(position).getStyle(), beersLists.get(position).getOunces());
                            Toast.makeText(beersview.this, "Ordered", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }

        searchBc.setAdapter(new ArrayAdapter<>(beersview.this, android.R.layout.simple_list_item_1, drop));
        /*
        * filer beer style by using beer style(Pale, Large, etc...) and search by beer name with Autocompletetextview.
        * */
        searchBc.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable arg0) {
                //beersLists = new ArrayList<>();
                set.setText("Crafted Beers");
                String text = searchBc.getText().toString();
                adapter.filter(text);
                adapter = new ListViewAdapter(beersview.this, beersLists);
                beerLview.setAdapter(adapter);
                beerLview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        long viewId = view.getId();

                        if (viewId == R.id.Alcohol) {
                            /*
                             * carting functionality(inserting userid and selected beer details).
                             * */
                            boolean t = databaseHelper.Cart(ID, beersLists.get(position).getName(), beersLists.get(position).getStyle(), beersLists.get(position).getOunces());
                            if (t == true) {
                                Toast.makeText(beersview.this, "Carted", Toast.LENGTH_SHORT).show();
                            }
                        }
                        if (viewId == R.id.Style) {
                            /*
                             * order functionality(inserting userid and selected beer details).
                             * */
                            boolean t = databaseHelper.Order(ID, beersLists.get(position).getName(), beersLists.get(position).getStyle(), beersLists.get(position).getOunces());
                            if (t == true) {
                                Toast.makeText(beersview.this, "Ordered", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                });
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1,
                                          int arg2, int arg3) {
            }

            @Override
            public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                                      int arg3) {
            }
        });

        searchBc.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                searchBc.showDropDown();
            }
        });
        searchBc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchBc.showDropDown();
            }
        });

        /*
        * Autocomplete text with select beer name and search beer details.
        * */
        searchBc.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                set.setText("Crafted Beers");
                beersLists = new ArrayList<>();
                Cursor cursor = databaseHelper.beerName((String) parent.getItemAtPosition((position)));
                if (cursor.getCount() == 0) {
                    Toast.makeText(beersview.this, "No Beers here", Toast.LENGTH_LONG).show();
                    beerLview.setVisibility(View.INVISIBLE);
                } else {
                    beerLview.setVisibility(View.VISIBLE);
                        do{
                            final beersList storyList = new beersList(cursor.getString(1), cursor.getString(2), cursor.getString(3));
                            beersLists.add(storyList);
                            Log.e("---->", cursor.getString(2)+cursor.getString(3));
                        } while (cursor.moveToNext());
                        adapter = new ListViewAdapter(beersview.this, beersLists);
                        beerLview.setAdapter(adapter);
                        /*
                        * Allow to user search beer by beer name.
                        * */
                        beerLview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                long viewId = view.getId();
                                try {
                                    if (viewId == R.id.Alcohol) {
                                        /*
                                        * carting functionality(inserting userid and selected beer details).
                                        * */
                                        databaseHelper.Cart(ID, beersLists.get(position).getName(), beersLists.get(position).getStyle(), beersLists.get(position).getOunces());
                                        Toast.makeText(beersview.this, "Carted", Toast.LENGTH_SHORT).show();
                                    }
                                    if (viewId == R.id.Style) {
                                        /*
                                         * order functionality(inserting userid and selected beer details).
                                         * */
                                        databaseHelper.Order(ID, beersLists.get(position).getName(), beersLists.get(position).getStyle(), beersLists.get(position).getOunces());
                                        Toast.makeText(beersview.this, "Ordered", Toast.LENGTH_SHORT).show();
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                }
            }
        });

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                set.setText("Your Cart");
                asc.setBackgroundColor(Color.parseColor("#1E8449"));
                order.setBackgroundColor(Color.parseColor("#1E8449"));
                cart.setBackgroundColor(Color.parseColor("#1B2631"));
                desc.setBackgroundColor(Color.parseColor("#1E8449"));
                beersLists = new ArrayList<>();
                /*
                *
                 * getting user carted data fetching with user loged in Id.
                 *
                * */
                final Cursor data = databaseHelper.addedcart(ID);
                if (data.getCount() == 0) {
                    Toast.makeText(beersview.this, "No Beers here", Toast.LENGTH_LONG).show();
                    beerLview.setVisibility(View.INVISIBLE);
                } else {
                    beerLview.setVisibility(View.VISIBLE);
                    while (data.moveToNext()) {
                        Log.e("---->", data.getString(1) + data.getString(4));
                        final beersList beersList = new beersList(data.getString(2), data.getString(3), data.getString(4));
                        beersLists.add(beersList);
                    }
                    Collections.reverse(beersLists);
                    adapter = new ListViewAdapter(beersview.this, beersLists);
                    beerLview.setAdapter(adapter);
                }
            }
        });

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                set.setText("Your Orders");
                asc.setBackgroundColor(Color.parseColor("#1E8449"));
                order.setBackgroundColor(Color.parseColor("#1B2631"));
                cart.setBackgroundColor(Color.parseColor("#1E8449"));
                desc.setBackgroundColor(Color.parseColor("#1E8449"));
                beersLists = new ArrayList<>();
                /*
                 * getting user order data fetching with user loged in Id.
                 * */
                final Cursor data = databaseHelper.viewOrder(ID);
                if (data.getCount() == 0) {
                    Toast.makeText(beersview.this, "No Beers here", Toast.LENGTH_LONG).show();
                    beerLview.setVisibility(View.INVISIBLE);
                } else {
                    beerLview.setVisibility(View.VISIBLE);
                    while (data.moveToNext()) {
                        final beersList beersList = new beersList(data.getString(2), data.getString(3), data.getString(4));
                        beersLists.add(beersList);
                    }
                    Collections.reverse(beersLists);
                    adapter = new ListViewAdapter(beersview.this, beersLists);
                    beerLview.setAdapter(adapter);
                }
            }
        });

        /*
        Ascending order with alcohol content
        * */
        asc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                set.setText("Alcohol content with low to high");
                asc.setBackgroundColor(Color.parseColor("#1B2631"));
                order.setBackgroundColor(Color.parseColor("#1E8449"));
                cart.setBackgroundColor(Color.parseColor("#1E8449"));
                desc.setBackgroundColor(Color.parseColor("#1E8449"));
                beersLists = new ArrayList<>();
                Cursor data = databaseHelper.Asc();
                if (data.getCount() == 0) {
                    Toast.makeText(beersview.this, "No Beers here", Toast.LENGTH_LONG).show();
                    beerLview.setVisibility(View.INVISIBLE);
                } else {
                    beerLview.setVisibility(View.VISIBLE);
                    while (data.moveToNext()) {
                        final beersList storyList = new beersList(data.getString(1), data.getString(2), data.getString(3));
                        beersLists.add(storyList);
                    }
                    adapter = new ListViewAdapter(beersview.this, beersLists);
                    beerLview.setAdapter(adapter);
                }
            }
        });

        /*
        * descending order with alcohol content
        * */
        desc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                set.setText("Alcohol content with high to low");
                asc.setBackgroundColor(Color.parseColor("#1E8449"));
                order.setBackgroundColor(Color.parseColor("#1E8449"));
                cart.setBackgroundColor(Color.parseColor("#1E8449"));
                desc.setBackgroundColor(Color.parseColor("#1B2631"));
                beersLists = new ArrayList<>();
                Cursor data = databaseHelper.Dsc();
                if (data.getCount() == 0) {
                    Toast.makeText(beersview.this, "No Beers here", Toast.LENGTH_LONG).show();
                    beerLview.setVisibility(View.INVISIBLE);
                } else {
                    beerLview.setVisibility(View.VISIBLE);
                    while (data.moveToNext()) {
                        final beersList storyList = new beersList(data.getString(1), data.getString(2), data.getString(3));
                        beersLists.add(storyList);
                    }
                    adapter = new ListViewAdapter(beersview.this, beersLists);
                    beerLview.setAdapter(adapter);
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.logout) {
            startActivity(new Intent(beersview.this, Login.class));
            Toast.makeText(beersview.this, "You have been successfully logged out!", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(beersview.this);
        builder.setTitle("Do you want to Exit?")
                .setMessage("Are you sure!")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                                                moveTaskToBack(true);
                                                android.os.Process.killProcess(android.os.Process.myPid());
                                                System.exit(1);
                        /*Toast.makeText(beersview.this, "You have been successfully logged out!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(beersview.this, MainActivity.class));*/
                    }
                }).setNegativeButton("Cancel", null).setCancelable(false);
        final AlertDialog alertDialog = builder.create();
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                alertDialog.getButton(android.support.v7.app.AlertDialog.BUTTON_POSITIVE).setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
                alertDialog.getButton(android.support.v7.app.AlertDialog.BUTTON_NEGATIVE).setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
                alertDialog.getButton(android.support.v7.app.AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#00bfff"));
                alertDialog.getButton(android.support.v7.app.AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#00bfff"));
                alertDialog.getButton(android.support.v7.app.AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
                alertDialog.getButton(android.support.v7.app.AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
            }
        });
        alertDialog.show();
    }
}
