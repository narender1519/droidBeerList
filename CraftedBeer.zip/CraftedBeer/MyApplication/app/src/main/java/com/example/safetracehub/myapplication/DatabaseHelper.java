package com.example.safetracehub.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by STH-NB-MICRO-004 on 01-11-2017.
 */

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "database.db";
    public static final String TABLE_NAME = "database_data";
    public static final String CORTTABLE= "cartdata";
    public static final String ORDER= "orderdata";
    public static final String REG= "Register";
    public static final String COL1 = "ID";
    public static final String COL2 = "ITEM1";
    public static final String COL3 = "ITEM2";
    public static final String TIME = "TIME";
    public static final String COL4 = "ITEM3";
    public static final String COL5 = "ITEM4";
    public static final String COL6 = "ITEM5";
    public static final String COL9 = "ITEM8";
    public static final String COL7 = "ITEM6";
    public static final String COL8 = "ITEM7";
    public static final String COL10 = "ITEM9";
    public static final String COL11 = "ITEM10";
    public static final String COL12 = "ITEM11";
    public static final String COL13 = "ITEM12";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        final String createTable = "CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ITEM1 TEXT," + "ITEM2 TEXT,"+ "TIME TEXT)";
        final String LoginTable = "CREATE TABLE " + CORTTABLE + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ITEM8 TEXT," + "ITEM3 TEXT," + "ITEM4 TEXT," +"ITEM5 TEXT)";
        final String getId = "CREATE TABLE " + REG + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ITEM6 TEXT," + "ITEM7 TEXT)";
        final String orders = "CREATE TABLE " + ORDER + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ITEM9 TEXT," + "ITEM10 TEXT," + "ITEM11 TEXT," +"ITEM12 TEXT)";
        db.execSQL(createTable);
        db.execSQL(LoginTable);
        db.execSQL(getId);
        db.execSQL(orders);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP IF TABLE EXISTS " + TABLE_NAME);
        db.execSQL("DROP IF TABLE EXISTS " + CORTTABLE);
        db.execSQL("DROP IF TABLE EXISTS " + REG);
        db.execSQL("DROP IF TABLE EXISTS " + ORDER);
        onCreate(db);
    }

    /*
    * Storing cloud data
    * */
    public boolean addData(String item1, String item2, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2, item1);
        contentValues.put(COL3, item2);
        contentValues.put(TIME, time);

        long result = db.insert(TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    /*
    * inserting userid with
    * */
    public boolean Cart(String id, String item4, String item5, String item6) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL9, id);
        contentValues.put(COL4, item4);
        contentValues.put(COL5, item5);
        contentValues.put(COL6, item6);
        //contentValues.put(COL7, item7);

        long result = db.insert(CORTTABLE, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Cursor addedcart(String id) {
        String selectQuery = "SELECT * FROM " + CORTTABLE + " WHERE "
                + COL9 + " = ?";
        String[] args={id};

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, args);
        //cursor.moveToFirst();
        System.out.println(cursor.getCount());
        return cursor;
    }

    public boolean Order(String id, String item4, String item5, String item6) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL10, id);
        contentValues.put(COL11, item4);
        contentValues.put(COL12, item5);
        contentValues.put(COL13, item6);
        //contentValues.put(COL7, item7);

        long result = db.insert(ORDER, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Cursor viewOrder(String id) {
        String selectQuery = "SELECT * FROM " + ORDER + " WHERE "
                + COL10 + " = ?";
        String[] args={id};

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, args);
        //cursor.moveToFirst();
        System.out.println(cursor.getCount());
        return cursor;
    }

    public boolean Reg(String item7, String item8) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL7, item7);
        contentValues.put(COL8, item8);

        long result = db.insert(REG, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Cursor Asc(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.query(TABLE_NAME, null, null, null, null, null, TIME + " ASC");
        data.moveToFirst();
        return data;
    }

    public Cursor Dsc(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.query(TABLE_NAME, null, null, null, null, null, TIME + " DESC");
        data.moveToFirst();
        return data;
    }

    public Cursor getListContents(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        return data;
    }

    public Cursor beerName(String email) {
        String selectQuery = "SELECT * FROM " + TABLE_NAME + " WHERE "
                + COL2 + " = ?";
        String[] args={email};

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, args);
        cursor.moveToFirst();
        System.out.println(cursor.getCount());
        return cursor;
    }

    public void delete(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ TABLE_NAME);
        db.close();
    }

    public String Login(String email,String pass) {
        String selectQuery = "SELECT * FROM " + REG + " WHERE "
                + COL7 + " = ?"+" AND " + COL8 + " = ?";
        String[] args={email, pass};

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor data = db.rawQuery(selectQuery, args);
        String a, b;
        String c=null;
        if(data.moveToFirst()){
            do{
                a = data.getString(1);
                b = data.getString(2);
                Log.e("a---->", a);
                Log.e("b---->", b);
                if(a.equals(email) && b.equals(pass)){
                    c=data.getString(0);
                    break;
                }
            }while(data.moveToNext());
        }
        return c;
    }
}
