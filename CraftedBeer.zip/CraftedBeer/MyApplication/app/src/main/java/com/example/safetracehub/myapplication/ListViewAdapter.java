package com.example.safetracehub.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Response;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ListViewAdapter extends BaseAdapter {
    Context mContext;
    LayoutInflater inflater;
    List<beersList> bcList;
    ArrayList<beersList> arrayList;

    public ListViewAdapter(Context context, List<beersList> bcList) {
        mContext = context;
        this.bcList = bcList;
        inflater = LayoutInflater.from(mContext);
        this.arrayList = new ArrayList<beersList>();
        this.arrayList.addAll(bcList);
    }

    private class ViewHolder{
        TextView bName,Style, Alocohol;
    }

    @Override
    public int getCount() {
        return bcList.size();
    }

    @Override
    public Object getItem(int position) {
        return bcList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View view, final ViewGroup parent) {
        ViewHolder holder;
        if (view==null){
            holder = new ViewHolder();
            view = inflater.inflate(R.layout.row, parent,false);

            //locate the views in row.xml
            holder.bName = (TextView) view.findViewById(R.id.bName);
            holder.Style = (TextView) view.findViewById(R.id.Style);
            holder.Alocohol = (TextView) view.findViewById(R.id.Alcohol);

            view.setTag(holder);

        }
        else {
            holder = (ViewHolder)view.getTag();
        }

        holder.bName.setText(bcList.get(position).getName());
        holder.Style.setText(bcList.get(position).getStyle());
        holder.Alocohol.setText("Alcohol Content:  "+bcList.get(position).getOunces());

        holder.Alocohol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ListView) parent).performItemClick(v, position, 0);
            }
        });

        holder.Style.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ListView) parent).performItemClick(v, position, 0);
            }
        });

        return view;
    }

    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        bcList.clear();
        if (charText.length() == 0) {
            bcList.addAll(arrayList);
        } else {
            for (beersList bc : arrayList) {
                if (bc.getStyle().toLowerCase(Locale.getDefault()).contains(charText)) {
                    bcList.add(bc);
                }
            }
        }
        notifyDataSetChanged();
    }
}
