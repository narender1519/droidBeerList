package com.example.safetracehub.myapplication;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class beersviewAdapter extends ArrayAdapter<beersList> {
    private Context mContext;
    LayoutInflater inflater;
    int mResource;
    private List<beersList> worldpopulationlist = null;
    private ArrayList<beersList> arraylist;

    public beersviewAdapter(@NonNull Context context, int resource, @NonNull ArrayList<beersList> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
        this.worldpopulationlist = objects;
        inflater = LayoutInflater.from(mContext);
        this.arraylist = new ArrayList<>();
        this.arraylist.addAll(worldpopulationlist);
    }

    public class ViewHolder {
        TextView rank;
        TextView country;
        TextView population;
    }

    @Override
    public int getCount() {
        return worldpopulationlist.size();
    }

    @Override
    public beersList getItem(int position) {
        return worldpopulationlist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull final ViewGroup parent) {
        String abv,ibu,id,name,style,ounces;
        abv = getItem(position).getAbv();
        ibu = getItem(position).getIbu();
        id = getItem(position).getId();
        name = getItem(position).getName();
        style = getItem(position).getStyle();
        ounces = getItem(position).getOunces();

        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource, parent, false);

        /*TextView beerName = (TextView) convertView.findViewById(R.id.bName);
        TextView place = (TextView) convertView.findViewById(R.id.place);
        TextView alh = (TextView) convertView.findViewById(R.id.alcohol);

        beerName.setText(name);
        place.setText(style);
        alh.setText("Alcohol Content: "+ounces);*/

        final ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.activity_beersview_adapter, null);
            // Locate the TextViews in listview_item.xml
           TextView beerName = (TextView) convertView.findViewById(R.id.bName);
            TextView place = (TextView) convertView.findViewById(R.id.place);
            TextView alh = (TextView) convertView.findViewById(R.id.alcohol);
            beerName.setText(name);
            place.setText(style);
            alh.setText("Alcohol Content: "+ounces);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        // Set the results into TextViews


        /*convertView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // Send single item click data to SingleItemView Class
                Intent intent = new Intent(mContext, SingleItemView.class);
                // Pass all data rank
                intent.putExtra("rank",(worldpopulationlist.get(position).getName()));
                // Pass all data country
                intent.putExtra("country",(worldpopulationlist.get(position).getStyle()));
                // Pass all data population
                intent.putExtra("population",(worldpopulationlist.get(position).getOunces()));
                // Pass all data flag
                // Start SingleItemView Class
                mContext.startActivity(intent);
            }
        });*/

        return convertView;
    }

    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        worldpopulationlist.clear();
        if (charText.length() == 0) {
            worldpopulationlist.addAll(arraylist);
        }
        else
        {
            for (beersList wp : arraylist)
            {
                if (wp.getName().toLowerCase(Locale.getDefault()).contains(charText))
                {
                    worldpopulationlist.add(wp);
                }
            }
        }
        notifyDataSetChanged();
    }

}
