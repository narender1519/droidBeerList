package com.example.safetracehub.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText user, pass;
    Button login;
    TextView reg;
    DatabaseHelper databaseHelper;
    private ProgressBar bar;
    TextView pleaseWt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        user = (EditText) findViewById(R.id.user);
        pass = (EditText) findViewById(R.id.pass);
        login = (Button) findViewById(R.id.login);
        reg = (TextView) findViewById(R.id.reg_link);
        bar = (ProgressBar) this.findViewById(R.id.progressBar_ID);
        pleaseWt = (TextView)findViewById(R.id.pls_Id);

        /*
        * Database calling.
        * */
        databaseHelper = new DatabaseHelper(this);

        /*
        * Initially deleting contents of the table for every time update table from cloud.
        **/
        databaseHelper.delete();

        /*
        * Api calling using Volley library(Google)
        * */
        String Api = "http://starlord.hackerearth.com/beercraft";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Api, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray jsonArray = new JSONArray(response);
                    for(int i=0;i<jsonArray.length();++i){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String abv = jsonObject.getString("abv");
                        String ibu = jsonObject.getString("ibu");
                        String id = jsonObject.getString("id");
                        String name = jsonObject.getString("name");
                        String style = jsonObject.getString("style");
                        String ounces = jsonObject.getString("ounces");
                        bar.setVisibility(View.VISIBLE);
                        pleaseWt.setVisibility(View.VISIBLE);
                        /*
                        * Adding data from cloud into sqlite once.
                        * */
                        databaseHelper.addData(name, style, abv);
                        bar.setVisibility(View.INVISIBLE);
                        pleaseWt.setVisibility(View.INVISIBLE);
                        reg.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                startActivity(new Intent(MainActivity.this, Register.class));
                            }
                        });
                        //login.setText("Login");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("error---->" , error.toString());
                bar.setVisibility(View.INVISIBLE);
                pleaseWt.setVisibility(View.INVISIBLE);
                Toast.makeText(MainActivity.this, "Please check internet connection", Toast.LENGTH_SHORT).show();
                if(error instanceof NetworkError){
                    Toast.makeText(MainActivity.this, "Please check internet connection", Toast.LENGTH_SHORT).show();
                }else if(error instanceof ServerError){
                    Toast.makeText(MainActivity.this, "Server not responding", Toast.LENGTH_SHORT).show();
                }/*.....errrors*/
                reg.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(MainActivity.this, "Please check internet connection", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(5000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(stringRequest);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(databaseHelper.Login(user.getText().toString(), pass.getText().toString()) == null){
                    Toast.makeText(MainActivity.this, "Login Error", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, beersview.class);
                    intent.putExtra("ID", databaseHelper.Login(user.getText().toString(), pass.getText().toString()));
                    startActivity(intent);
                }
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.register) {
            startActivity(new Intent(MainActivity.this, Register.class));
            return true;
        }
        return false;
    }
}
